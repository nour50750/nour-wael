from pathlib import Path
from html import escape as E
import json,re,shutil
ROOT=Path(__file__).resolve().parents[1]; SITE=ROOT/'site'; SRC=ROOT/'src'
BASE='/nour-wael'; ORIGIN='https://nour50750.github.io'+BASE
cats={'ar':{'all':'كل الأعمال','growth':'الإعلانات والنتائج','ui':'المواقع والواجهات','branding':'الهويات البصرية','social':'المحتوى والحملات','seo':'تحسين محركات البحث'},'en':{'all':'All work','growth':'Advertising & results','ui':'Websites & interfaces','branding':'Brand identities','social':'Content & campaigns','seo':'Search & SEO'}}
def asset(s):return BASE+'/assets/'+s
def txt(p,k,l,default=''):return p.get(k+'_'+l,default)
def home(l):return BASE+('/en/' if l=='en' else '/')
def library(l):return home(l)+'work/'
def detail(p,l):return library(l)+p['id']+'/'
def load(n):return json.loads((SRC/n).read_text())
projects=load('cases.json')
for p in projects:
 p.setdefault('gallery_files',[])
 if p['id']!='medical-sleep':p['evidence']='library/'+p['id']+'-evidence.webp'
visual=load('visual-projects.json')
for p in visual:
 if p['id']=='tholathiyat':
  parent=next(x for x in projects if x['id']==p['id']);parent['gallery_files']=[p['gallery_files'][1]];continue
 p['categories']=[p['category']];projects.append(p)
ui_info=[
 (8,'mango-jazan','مانجو جيزان','Mango Jazan','واجهة متجر تنقل روح المنتج المحلي بأصفر المانجو، وصور المزارع، وتصنيفات المنتجات.','A storefront shaped by mango-yellow accents, farm photography and clear product categories.'),
 (10,'fkretk','فكرتك','Fkretk','واجهة خدمات تسويقية تجمع التعريف بالوكالة وباقات الخدمات ومسار التواصل في تسلسل واضح.','A marketing-services interface connecting agency positioning, service packages and enquiry paths.'),
 (13,'rabhan','ربحان','Rabhan','صفحة خدمات تسويق باللون الأخضر تشرح الخدمات وتوجّه الزائر إلى التواصل.','A green marketing-services page explaining the offer and guiding visitors towards an enquiry.'),
 (14,'sibaq','سباق','Sibaq','واجهة وكالة بدرجات دافئة تجمع تقديم الفريق والخدمات والباقات ضمن هوية عربية واضحة.','A warm-toned agency interface bringing together its team, services and packages in an Arabic visual identity.'),
 (1,'beehome','بي هوم','Bee Home','واجهة منتجات منزلية تعتمد على التصوير الهادئ وتصنيفات المفروشات وبطاقات المنتجات.','A homeware storefront using calm photography, bedding categories and consistent product cards.'),
 (4,'alzahami','الزحامي','Al Zahami','واجهة أثاث بألوان محايدة وخضراء، تصنّف المنتجات بحسب الغرف وتبرز التشكيلات.','A neutral-and-green furniture storefront with room-based categories and prominent collections.'),
 (5,'albadr-oud','البدر للعود','Al Badr Oud','واجهة عطور وعود بألوان داكنة وتفاصيل ذهبية، مع تنظيم الفئات والعروض والمنتجات.','A dark oud and fragrance storefront with gold details and organised categories, offers and products.'),
 (6,'space-store','فضاء ستور','Space Store','واجهة متجر منتجات وخدمات رقمية بلغة بنفسجية، وأقسام للألعاب والاشتراكات.','A purple digital-products storefront organising games, subscriptions and services.'),
 (7,'shams','شمس','Shams','واجهة تعريفيّة تمزج الصور السعودية بالأزرق والأصفر لعرض هوية النشاط وخدماته.','A company interface blending Saudi imagery with blue and yellow to present its identity and services.'),
 (2,'qe-tourism','جائزة الجودة والتميز السياحي','Tourism Quality & Excellence Award','تصميم موقع للجائزة يعرض فئاتها ومعلوماتها بصريًا في تجربة عربية منظمة.','An Arabic award website design presenting tourism categories and programme information.'),
 (15,'allamea','اللامع لإضاءات السيارات','Al Lamea Auto Lighting','واجهة متجر داكنة تجعل إضاءة السيارات هي العنصر البصري الرئيسي مع تصنيفات ومنتجات واضحة.','A dark automotive-lighting storefront that places the product effect at the centre of the visual story.'),
 (16,'shatlat','شتلات','Shatlat','واجهة نباتات بمساحات بيضاء وخضراء، تجمع أنواع الشتلات والمنتجات في تجربة هادئة.','A plant storefront with white space, green accents and clearly grouped plant and product categories.')]
for i,id,ar,en,da,de in ui_info:
 projects.append({'id':id,'ar':ar,'en':en,'categories':['ui'],'cover':f'library/ui-{i}-cover.webp','gallery_files':[f'library/ui-{i}-full.webp'],'description_ar':da,'description_en':de,'scope_ar':'تصميم واجهة كاملة من ملفات المشروع.','scope_en':'Complete interface design from the project archive.'})
for p in load('local-projects.json'):
 q={'id':p['id'],'ar':p['ar']['name'],'en':p['en']['name'],'categories':['ui'],'cover':'library/'+p['id']+'-cover.webp','gallery_files':['library/'+p['id']+'-full.webp']}
 for l in ['ar','en']:
  for old,new in [('desc','description'),('title','headline'),('challenge','challenge'),('approach','approach'),('scope','scope')]:q[new+'_'+l]=p[l][old]
 projects.append(q)
old=load('original-projects.json')
for i,p in enumerate(old['ar']):
 pe=old['en'][i];q={'id':p['id'],'ar':p['name'],'en':pe['name'],'categories':['branding'] if p['category']=='branding' else ['ui'],'cover':p['image'],'gallery_files':[p['full']]}
 if p.get('extra'):q['gallery_files'].append(p['extra'])
 if p.get('pdf'):q['pdf_file']=p['pdf']
 for l,item in [('ar',p),('en',pe)]:
  for oldkey,newkey in [('desc','description'),('challenge','challenge'),('approach','approach'),('scope','scope')]:q[newkey+'_'+l]=item[oldkey]
 projects.append(q)
projects.append({'id':'abojabaa','ar':'أبو جبعا بايك','en':'Abojabaa Bike','categories':['ui','social'],'cover':'abojabaa.webp','gallery_files':['abojabaa.webp'],'url':'https://abojabaa-bike.com/','description_ar':'تحسين تجربة متجر دراجات وتوجيه المحتوى المرئي للحملات والمنتجات.','description_en':'Motorcycle storefront experience and visual direction for campaign and product content.','scope_ar':'الإشراف على تحسين واجهة المتجر والبنرات والمحتوى الإعلاني بالتنسيق مع فريق التنفيذ.','scope_en':'Oversight of storefront improvements, banners and advertising content in coordination with the delivery team.'})
priority=['medical-sleep','anakeed','nsea','mango-jazan','stars-spa','tholathiyat','raheeq','fkretk','hawa','arhb','beehome','sibaq','rabhan','oven']
projects.sort(key=lambda p:priority.index(p['id']) if p['id'] in priority else len(priority))
assert len({p['id'] for p in projects})==len(projects)
def badge(p,l):return 'دراسة حالة' if l=='ar' and p.get('case') else 'CASE STUDY' if p.get('case') else cats[l][p['categories'][0]]
def poster(p,l):
 if p.get('cover'):return f'<img src="{asset(p["cover"])}" alt="{E(p[l])}" loading="lazy" width="1200" height="850">'
 m=p['metrics'][0];return f'<div class="metric-poster" style="--accent:{p.get("color","#ccf76b")}"><span class="poster-grid" aria-hidden="true"></span><span class="poster-brand">{E(p[l])}</span><strong dir="ltr">{m[0]}</strong><span>{m[1 if l=="ar" else 2]}</span><small>{"من بيانات المشروع" if l=="ar" else "FROM PROJECT DATA"}</small></div>'
def card(p,l):
 search=' '.join([p['ar'],p['en'],txt(p,'description',l),*p['categories']])
 return f'<article class="archive-card" data-categories="{" ".join(p["categories"])}" data-search="{E(search)}"><a href="{detail(p,l)}" class="archive-card-link"><div class="archive-visual">{poster(p,l)}<span class="archive-badge">{badge(p,l)}</span><span class="card-open" aria-hidden="true">↗</span></div><div class="archive-info"><div class="archive-meta">{" / ".join(cats[l][x] for x in p["categories"])}</div><h3>{E(p[l])}</h3><p>{E(txt(p,"description",l))}</p><span class="archive-read">{"اقرأ دراسة الحالة" if p.get("case") and l=="ar" else "Read case study" if p.get("case") else "استكشف المشروع" if l=="ar" else "Explore project"}<span aria-hidden="true">↗</span></span></div></a></article>'
def header(l,other):
 ar=l=='ar';return f'<a class="skip-link" href="#main">{"انتقل للمحتوى" if ar else "Skip to content"}</a><header class="archive-header"><nav class="container"><a class="brand" href="{home(l)}"><span class="monogram">nw</span><span>{"نور وائل" if ar else "Nour Wael"}<small>DESIGN · BUILD · LEAD</small></span></a><div class="archive-nav"><a href="{home(l)}">{"الرئيسية" if ar else "Home"}</a><a href="{library(l)}">{"مكتبة الأعمال" if ar else "Work library"}</a><a href="{home(l)}#contact">{"تواصل" if ar else "Contact"}</a><a class="lang" href="{other}">{"EN" if ar else "عربي"}</a></div></nav></header>'
def footer(l):return f'<footer class="archive-footer container"><a class="brand" href="{home(l)}">Nour Wael<span>DESIGN · BUILD · LEAD</span></a><a href="https://wa.me/201030390815" target="_blank" rel="noopener">{"لنتحدث عن مشروعك" if l=="ar" else "Let’s talk about your project"} ↗</a><span>© Nour Wael</span></footer>'
def shell(l,title,description,path,body,other,image='assets/social-cover.png'):
 return f'''<!doctype html><html lang="{l}" dir="{'rtl' if l=='ar' else 'ltr'}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#11130f"><title>{E(title)} | Nour Wael</title><meta name="description" content="{E(description)}"><link rel="canonical" href="https://nour50750.github.io{path}"><link rel="alternate" hreflang="{'en' if l=='ar' else 'ar'}" href="https://nour50750.github.io{other}"><meta property="og:title" content="{E(title)} | Nour Wael"><meta property="og:description" content="{E(description)}"><meta property="og:url" content="https://nour50750.github.io{path}"><meta property="og:type" content="website"><meta property="og:image" content="{ORIGIN}/{image}"><link rel="icon" href="{BASE}/assets/favicon.svg"><link rel="stylesheet" href="{BASE}/style.css"><link rel="stylesheet" href="{BASE}/library.css"><script src="{BASE}/library.js" defer></script></head><body class="archive-page"><div class="reading-progress" aria-hidden="true"></div>{header(l,other)}<main id="main">{body}</main>{footer(l)}<dialog class="image-viewer" aria-label="{'عارض الصور' if l=='ar' else 'Image viewer'}"><button class="viewer-close" aria-label="{'إغلاق' if l=='ar' else 'Close'}">×</button><img alt=""><a class="viewer-original" target="_blank" rel="noopener">{'فتح الصورة كاملة' if l=='ar' else 'Open full image'} ↗</a></dialog></body></html>'''
def write(url,html):
 p=SITE/url.removeprefix(BASE+'/')/'index.html';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(html)
for l in ['ar','en']:
 ar=l=='ar';other='en' if ar else 'ar';cs=[p for p in projects if p.get('case')]
 labels={'ar':['مشروعات تُرى.','ونتائج تُقرأ.','مكتبة أعمال نور وائل','من تصميم الواجهات والهويات إلى قيادة التنفيذ والتسويق. استكشف العمل، وافهم دوره، واقرأ النتائج في سياقها.','مشروعًا مختارًا','دراسات حالة','مجالات متكاملة','ابحث باسم البراند أو نوع العمل','عرض','مشروع','لم نجد أعمالًا تطابق البحث. جرّب اسمًا آخر أو غيّر التصنيف.'],'en':['Work you can see.','Results you can read.','THE WORK LIBRARY','From interfaces and identities to delivery and marketing. Explore the work, understand its role, and read the results in context.','Selected projects','Case studies','Connected disciplines','Search brands or disciplines','Showing','projects','No projects match your search. Try another term or category.']}[l]
 filters=''.join(f'<button class="library-filter" data-category="{k}" aria-pressed="{str(k=="all").lower()}">{v}<span>{len(projects) if k=="all" else sum(k in p["categories"] for p in projects)}</span></button>' for k,v in cats[l].items())
 featured=''.join(f'<a href="{detail(p,l)}"><span>{p[l]}</span><strong dir="ltr">{p["metrics"][0][0]}</strong><small>{p["metrics"][0][1 if ar else 2]}</small><b aria-hidden="true">↗</b></a>' for p in cs[:4])
 body=f'<section class="library-hero container"><div class="eyebrow">{labels[2]} / 01—{len(projects):02}</div><h1>{labels[0]}<br><em>{labels[1]}</em></h1><div class="library-intro"><p>{labels[3]}</p><div class="library-counts"><div><b>{len(projects):02}</b><span>{labels[4]}</span></div><div><b>06</b><span>{labels[5]}</span></div><div><b>05</b><span>{labels[6]}</span></div></div></div></section><section class="case-ribbon container" aria-label="{labels[5]}">{featured}</section><section class="library-browser container" id="browse"><div class="library-tools"><label class="search-field"><span aria-hidden="true">⌕</span><input id="project-search" type="search" placeholder="{labels[7]}" aria-label="{labels[7]}"><kbd>/</kbd></label><div class="library-filters" aria-label="{labels[6]}">{filters}</div><div class="library-summary" role="status" aria-live="polite">{labels[8]} <b id="visible-count">{len(projects)}</b> {labels[9]}<span>{"اختر مشروعًا لتصفّح التفاصيل والتصميمات كاملة" if ar else "Open a project for the full story and visuals"}</span></div></div><div class="archive-grid">'+''.join(card(p,l) for p in projects)+f'</div><p id="no-results" hidden>{labels[10]}</p></section><section class="library-cta container"><span class="eyebrow">{"الفكرة التالية قد تكون فكرتك" if ar else "YOUR IDEA COULD BE NEXT"}</span><h2>{"لنصنع تجربة<br>تستحق أن تُعرض." if ar else "Let’s build something<br>worth showing."}</h2><a class="btn btn-primary" href="https://wa.me/201030390815" target="_blank" rel="noopener">{"تواصل معي" if ar else "Get in touch"} ↗</a></section>'
 write(library(l),shell(l,labels[2],labels[3],library(l),body,library(other)))
 for p in projects:
  case=p.get('case');title=txt(p,'headline',l,p[l]);desc=txt(p,'description',l)
  metrics='<div class="case-metrics">'+''.join(f'<div><strong dir="ltr">{m[0]}</strong><span>{m[1 if ar else 2]}</span></div>' for m in p.get('metrics',[]))+'</div>' if case else ''
  overview=''
  if case:
   overview=f'<div class="case-context"><div><span>{"الدور" if ar else "ROLE"}</span><p>{txt(p,"role",l)}</p></div><div><span>{"فترة القياس" if ar else "REPORTING PERIOD"}</span><p>{txt(p,"period",l)}</p></div></div>'
  scope=txt(p,'scope',l,'تصميم بصري وعرض نماذج من ملفات المشروع.' if ar else 'Visual design and samples from the project archive.')
  narrative=f'<section class="case-narrative"><div class="case-label"><span>01 / {"الفكرة والنطاق" if ar else "IDEA & SCOPE"}</span><h2>{"وراء العمل" if ar else "Behind the work"}</h2></div><div><p class="lead">{desc}</p><p>{txt(p,"challenge",l,scope)}</p>'
  if txt(p,'approach',l):narrative+=f'<p>{txt(p,"approach",l)}</p>'
  if case:narrative+='<ol class="case-actions">'+''.join(f'<li><span>{i+1:02}</span><p>{text}</p></li>' for i,text in enumerate(p['actions_'+l]))+'</ol>'
  else:narrative+=f'<div class="scope-tag">{scope}</div>'
  narrative+='</div></section>'
  if case:narrative+=f'<section class="case-narrative result-block"><div class="case-label"><span>02 / {"النتيجة" if ar else "OUTCOME"}</span><h2>{"ما الذي تحقق؟" if ar else "What did it deliver?"}</h2></div><div><p class="lead">{txt(p,"result",l)}</p><p class="measurement-note">{txt(p,"note",l)}</p></div></section>'
  gallery='';files=p.get('gallery_files',[])
  if p.get('evidence'):files=[p['evidence']]+files
  for i,f in enumerate(files):
   label=('لقطة النتائج من ملفات المشروع' if ar else 'Performance capture from the project archive') if f==p.get('evidence') else ('الموقع الرسمي الحالي · 4 نوفمبر 2026' if ar else 'Current official website · 4 November 2026') if p['id']=='medical-sleep' else ('من التصميمات الأصلية للمشروع' if ar else 'From the original project designs')
   full='full-design' if 'full' in f else ''
   gallery+=f'<figure class="case-figure {full}"><button class="gallery-image" data-full="{asset(f)}" aria-label="{E(p[l])} — {"تكبير الصورة" if ar else "Enlarge image"}"><img src="{asset(f)}" alt="{E(p[l])} — {label}" loading="lazy"></button><figcaption><span>{i+1:02} / {label}</span><a href="{asset(f)}" target="_blank" rel="noopener">{"الحجم الكامل" if ar else "Full resolution"} ↗</a></figcaption></figure>'
  links=''
  if p.get('pdf_file'):links+=f'<a class="btn btn-primary" href="{asset(p["pdf_file"])}" target="_blank" rel="noopener">{"ملف الهوية PDF" if ar else "Brand identity PDF"} ↗</a>'
  if p.get('url'):links+=f'<a class="btn" href="{p["url"]}" target="_blank" rel="noopener">{"زيارة الموقع" if ar else "Visit website"} ↗</a>'
  gallery=f'<section class="case-gallery"><div class="section-heading"><h2>{"العمل عن قرب" if ar else "A closer look"}</h2><p>{"اضغط على أي صورة لاستكشاف التفاصيل." if ar else "Open any image to explore the details."}</p></div>{gallery}<div class="case-links">{links}</div></section>'
  related=[x for x in projects if x['id']!=p['id'] and any(c in p['categories'] for c in x['categories'])][:3]
  body=f'<div class="container case-container"><a class="back-to-work" href="{library(l)}">← {"مكتبة الأعمال" if ar else "Work library"}</a><section class="case-hero"><div class="eyebrow">{badge(p,l)} / {" · ".join(cats[l][x] for x in p["categories"])}</div><span class="case-brand">{E(p[l])}</span><h1>{title}</h1>{overview}{metrics}</section><div class="case-hero-visual">{poster(p,l)}</div>{narrative}{gallery}<section class="related"><div class="section-heading"><h2>{"استكشف أيضًا" if ar else "Explore more"}</h2><a href="{library(l)}">{"كل الأعمال" if ar else "All work"} ↗</a></div><div class="archive-grid">'+''.join(card(x,l) for x in related)+'</div></section></div>'
  write(detail(p,l),shell(l,p[l]+' — '+('دراسة حالة' if case and ar else 'Case study' if case else 'عرض المشروع' if ar else 'Project'),desc,detail(p,l),body,detail(p,other),'assets/'+p.get('cover','social-cover.png')))
 # Preserve every home section except the requested work showcase.
 base=SRC/('home-'+l+'.html')
 if not base.exists():shutil.copy(SITE/('en/index.html' if l=='en' else 'index.html'),base)
 h=base.read_text();selected=[next(p for p in projects if p['id']==id) for id in ['medical-sleep','anakeed','nsea','mango-jazan','stars-spa','raheeq']]
 showcase=f'<section class="section library-home" id="work"><div class="container"><div class="section-heading"><div><div class="eyebrow">01 / {"مكتبة الأعمال ودراسات الحالة" if ar else "WORK & CASE STUDIES"}</div><h2>{"تصميم يصنع الحضور.<br>وعمل تصفه النتائج." if ar else "Design that builds presence.<br>Work with measurable outcomes."}</h2></div><p>{"مشروعات من الواجهات والهويات والمحتوى، ودراسات حالة تربط التنفيذ بالنتائج. لكل عمل صفحة تشرح الفكرة والدور والتفاصيل." if ar else "Interfaces, identities and creative work alongside case studies connecting delivery to results. Each project has its own story and detail."}</p></div><div class="archive-grid">'+''.join(card(p,l) for p in selected)+f'</div><a class="library-all" href="{library(l)}"><span><strong>{"استكشف مكتبة الأعمال كاملة" if ar else "Explore the complete work library"}</strong><small>{len(projects)} {"مشروعًا مختارًا · 6 دراسات حالة · بحث وتصنيفات" if ar else "selected projects · 6 case studies · search & filters"}</small></span><b aria-hidden="true">↗</b></a></div></section>'
 h,n=re.subn(r'<section[^>]*id="work"[^>]*>.*?</section>',lambda m:showcase,h,count=1,flags=re.S);assert n==1
 # Supersede the old Medical Sleep/Mammoth modal so no incorrect image or link remains.
 h=re.sub(r'<template id="project-mammoth">.*?</template>','',h,flags=re.S)
 h=h.replace('</head>',f'<link rel="stylesheet" href="{BASE}/library.css"></head>')
 h=h.replace('href="#work"','href="'+library(l)+'"')
 # Link the named client tiles to their project pages when available.
 for p in projects:
  name=E(p[l]);h=h.replace(f'<span>{name}</span></li>',f'<span><a href="{detail(p,l)}">{name} ↗</a></span></li>')
 (SITE/('en/index.html' if l=='en' else 'index.html')).write_text(h)
 urls=[home(l),library(l)]+[detail(p,l) for p in projects]
 if l=='ar':allurls=urls
 else:allurls+=urls
(SITE/'sitemap.xml').write_text('<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+''.join('<url><loc>https://nour50750.github.io'+u+'</loc></url>' for u in allurls)+'</urlset>')
(SRC/'published-catalog.json').write_text(json.dumps(projects,ensure_ascii=False,indent=2))
print('Built',len(projects),'projects,',len(allurls),'bilingual pages; 6 case studies')
