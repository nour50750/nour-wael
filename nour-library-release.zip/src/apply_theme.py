from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
snippet='<script src="/nour-wael/theme-init.js"></script><link rel="stylesheet" href="/nour-wael/theme.css"><script src="/nour-wael/theme.js" defer></script>'
for p in (ROOT/'site').rglob('*.html'):
 s=p.read_text()
 if 'theme-init.js' not in s:s=s.replace('</head>',snippet+'</head>')
 p.write_text(s)
print('Theme controls enabled across all pages')
